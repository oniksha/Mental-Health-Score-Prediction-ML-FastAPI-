# Mental Health Signal: Student Wellbeing Score Predictor

Predicts a student's **mental health score** (about 3.6 to 9.4) from social media usage and lifestyle habits, using a Random Forest regression model.

## Features
- **Live predictor:** sliders and typed inputs for 12 features, sample student profiles, what-if charts
- **Final report:** habit radar, personalised recommendations, comparison with 5,000 students, 7-day action plan
- **History:** saved results with a score trend; reopen any past report
- **Sign-in screen:** UI prototype (no real accounts are created)

## How the model was built
1. Cleaned the data (duplicates removed, negative activity values clipped to 0)
2. EDA: social media usage and sleep are the strongest drivers of the score
3. Feature engineering: 111 countries grouped into 11
4. `ColumnTransformer` + `Pipeline`: log + scaling, ordinal encoding (stress level) and one-hot encoding
5. Compared Linear Regression and Random Forest; Random Forest performed better
6. Served the trained pipeline with **FastAPI**

## Tech stack
Python, Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn, FastAPI, HTML/CSS/JavaScript

## Live demo
`index.html` is a single self-contained file (no build step). It runs a lightweight copy of the trained Random Forest in the browser, so it works without a server. To run the real model, use the FastAPI app (`main.py`).

## Disclaimer
Educational project. It is not a medical or clinical tool.
